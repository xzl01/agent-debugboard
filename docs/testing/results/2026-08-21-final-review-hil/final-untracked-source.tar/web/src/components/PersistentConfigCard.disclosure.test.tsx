import { afterEach, describe, expect, it, vi } from "vitest";
import { PersistentConfigApiError } from "@/lib/persistentConfig";
import {
  click,
  config,
  configRow,
  mount,
  powerItem,
  state,
  type CardView,
} from "./PersistentConfigCard.testUtils";

const CONTENT_ID = "persistent-config-content";
const EN_COLLAPSE = "Collapse saved configuration";
const EN_EXPAND = "Expand saved configuration";
const ZH_COLLAPSE = "折叠已保存配置";
const ZH_EXPAND = "展开已保存配置";

function disclosureButton(host: HTMLElement, label: string): HTMLButtonElement {
  const found = [...host.querySelectorAll("button")].find(
    (candidate) => candidate.getAttribute("aria-label") === label
  );
  if (!found) throw new TypeError(`Disclosure button not found: ${label}`);
  return found;
}

function contentRegion(host: HTMLElement): HTMLElement {
  const found = host.querySelector<HTMLElement>(`#${CONTENT_ID}`);
  if (!found) throw new TypeError(`Controlled region not found: ${CONTENT_ID}`);
  return found;
}

let view: CardView | null = null;
afterEach(() => {
  view?.close();
  view = null;
  localStorage.clear();
});

describe("PersistentConfigCard disclosure", () => {
  it("defaults to collapsed with accessible expand semantics and a stable controlled region", () => {
    // Given: a card with one saved power row
    view = mount(state({ config: config([powerItem("firmware.default")]) }));

    // When: the card renders without any interaction
    // Then: a labelled expand disclosure controls a hidden stable region
    const disclosure = disclosureButton(view.host, EN_EXPAND);
    expect(disclosure.type).toBe("button");
    expect(disclosure.getAttribute("title")).toBe(EN_EXPAND);
    expect(disclosure.getAttribute("aria-expanded")).toBe("false");
    expect(disclosure.getAttribute("aria-controls")).toBe(CONTENT_ID);

    const region = contentRegion(view.host);
    expect(region.hidden).toBe(true);
    expect(region.textContent).toContain("firmware.default");
  });

  it("expands and re-collapses the controlled region without calling save, clear, or refresh", () => {
    // Given: a mounted card whose mutations are spied
    const fixture = state({ config: config([powerItem("firmware.toggle")]) });
    view = mount(fixture);
    const expand = disclosureButton(view.host, EN_EXPAND);

    // When: the disclosure is focused and clicked once to expand
    expand.focus();
    click(expand);

    // Then: the button flips to collapse semantics, keeps focus, and the region is visible
    const collapse = disclosureButton(view.host, EN_COLLAPSE);
    expect(collapse.getAttribute("title")).toBe(EN_COLLAPSE);
    expect(collapse.getAttribute("aria-expanded")).toBe("true");
    expect(collapse.getAttribute("aria-controls")).toBe(CONTENT_ID);
    const shown = contentRegion(view.host);
    expect(shown.hidden).toBe(false);
    expect(shown.textContent).toContain("firmware.toggle");
    expect(document.activeElement).toBe(collapse);

    // When: the disclosure is clicked again to re-collapse
    click(collapse);

    // Then: collapsed semantics, focus, and hidden region return, and no mutation ran
    const restored = disclosureButton(view.host, EN_EXPAND);
    expect(restored.getAttribute("aria-expanded")).toBe("false");
    expect(document.activeElement).toBe(restored);
    expect(contentRegion(view.host).hidden).toBe(true);
    expect(fixture.save).not.toHaveBeenCalled();
    expect(fixture.clear).not.toHaveBeenCalled();
    expect(fixture.refresh).not.toHaveBeenCalled();
  });

  it("preserves the row selection across collapse and re-expand", () => {
    // Given: a collapsed card the user expands before selecting a row
    view = mount(state({ config: config([powerItem("firmware.keep-selection")]) }));
    click(disclosureButton(view.host, EN_EXPAND));
    click(configRow(view.host, "firmware.keep-selection"));
    expect(configRow(view.host, "firmware.keep-selection").getAttribute("aria-checked")).toBe("true");

    // When: the card is collapsed and re-expanded
    click(disclosureButton(view.host, EN_COLLAPSE));
    click(disclosureButton(view.host, EN_EXPAND));

    // Then: the selection survives the toggle instead of being reset
    expect(configRow(view.host, "firmware.keep-selection").getAttribute("aria-checked")).toBe("true");
  });

  it("keeps the collapsed region hidden across busy updates and presents busy feedback after expanding", () => {
    // Given: a healthy card collapsed by default
    const busy = new PersistentConfigApiError({ kind: "busy", activity: "capture" }, "busy");
    view = mount(state({ config: config([powerItem("firmware.busy")]) }));
    expect(contentRegion(view.host).hidden).toBe(true);

    // When: a busy state arrives while the card is still collapsed
    view.update(state({ config: config([powerItem("firmware.busy")]), error: busy }));

    // Then: the region stays hidden and the disclosure stays collapsed
    expect(contentRegion(view.host).hidden).toBe(true);
    expect(disclosureButton(view.host, EN_EXPAND).getAttribute("aria-expanded")).toBe("false");

    // When: the card is expanded
    click(disclosureButton(view.host, EN_EXPAND));

    // Then: the region is visible again and the current busy feedback is presented
    expect(contentRegion(view.host).hidden).toBe(false);
    expect(view.host.textContent).toContain("Power capture is using the board");
  });

  it("exposes localized Chinese disclosure labels in both states", () => {
    // Given: a card mounted in Chinese
    view = mount(state({ config: config([powerItem("firmware.locale")]) }), { lang: "zh" });

    // When: the card renders collapsed by default
    // Then: the expand disclosure carries the Chinese accessible label and title
    const expand = disclosureButton(view.host, ZH_EXPAND);
    expect(expand.getAttribute("title")).toBe(ZH_EXPAND);
    expect(expand.getAttribute("aria-expanded")).toBe("false");
    expect(expand.getAttribute("aria-controls")).toBe(CONTENT_ID);

    // When: the disclosure is clicked
    click(expand);

    // Then: the collapse disclosure carries the Chinese accessible label and title
    const collapse = disclosureButton(view.host, ZH_COLLAPSE);
    expect(collapse.getAttribute("title")).toBe(ZH_COLLAPSE);
    expect(collapse.getAttribute("aria-expanded")).toBe("true");
  });

  it("does not trigger mutations when toggled repeatedly", () => {
    // Given: a mounted card with spied mutations
    const save = vi.fn().mockResolvedValue(undefined);
    const clear = vi.fn().mockResolvedValue(undefined);
    const refresh = vi.fn().mockResolvedValue(undefined);
    view = mount(state({ config: config([powerItem("firmware.spam")]), save, clear, refresh }));

    // When: the disclosure is toggled several times
    for (let round = 0; round < 3; round += 1) {
      click(disclosureButton(view.host, EN_EXPAND));
      click(disclosureButton(view.host, EN_COLLAPSE));
    }

    // Then: no save, clear, or refresh call ever fired
    expect(save).not.toHaveBeenCalled();
    expect(clear).not.toHaveBeenCalled();
    expect(refresh).not.toHaveBeenCalled();
  });
});
